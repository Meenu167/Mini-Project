function uploadImage() 
    {
        var input = document.getElementById('imageUpload');
        var container = document.getElementById('image');
        var errorMessage = document.getElementById('errorMessage');
        
        if (input.files && input.files[0]) {
          var reader = new FileReader();
          
          reader.onload = function (e) {
            container.innerHTML = '<img src="' + e.target.result + '" alt="Uploaded Image">';
            errorMessage.style.display = 'none';
          }
          
          reader.readAsDataURL(input.files[0]);
        } 
        else {
          container.innerHTML = '';
          errorMessage.style.display = 'block';
        }
     }