document.addEventListener("DOMContentLoaded", function() {
    var navLinks = document.querySelectorAll("nav a");
  
    navLinks.forEach(function(link) {
      link.addEventListener("click", function(event) {
        event.preventDefault();
        var targetSection = document.querySelector(this.getAttribute("href"));
  
        if (isElementFullyVisible(targetSection)) {
          // Section is fully visible, no need to scroll
          return;
        }
  
        targetSection.scrollIntoView({ behavior: "smooth", block: "start" });
      });
    });
  
    function isElementFullyVisible(element) {
      var rect = element.getBoundingClientRect();
      return (
        rect.top >= 0 &&  rect.bottom <= (window.innerHeight || document.documentElement.clientHeight)
      );
    }
  });